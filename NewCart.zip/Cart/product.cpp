#include "product.h"

Product::Product(QString _name, QString _catagory , int _price , int _number){
    name = _name;
    catagory = _catagory;
    price = _price;
    number = _number;
    spin = NULL;
}
