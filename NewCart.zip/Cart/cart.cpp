
#include "cart.h"
#include "ui_cart.h"
#include "additemdialog.h"
#include "addcartdialog.h"

int Cart::counter = 0;

Cart::Cart(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Cart)
{
    ui->setupUi(this);
    Product x1("Rice","Food",300,20);
    Product x2("TShirt","Clothes",500,17);
    Product x3("Pooshak","Health Care",150,29);
    Product x4("Cheese","Food",100,100);
    Product x5("Coffee","Drink",150,120);
    Product x6("Apple","Fruits",100,40);
    Product x7("Banana","Fruits",150,30);
    Product x8("Bread","Food",50,20);
    Product x9("Soap","Health Care",300,13);
    Product x10("TV","Electronic",1000,10);

    pro.push_back(x1);
    pro.push_back(x2);
    pro.push_back(x3);
    pro.push_back(x4);
    pro.push_back(x5);
    pro.push_back(x6);
    pro.push_back(x7);
    pro.push_back(x8);
    pro.push_back(x9);
    pro.push_back(x10);

}

Cart::~Cart()
{
    delete ui;
}


void Cart::on_additembtn_clicked()
{
    additemDialog *t = new additemDialog(this);
    t->show();
    connect(t,SIGNAL(sendProduct(Product)),this,SLOT(newPro(Product)));

}

void Cart::on_pushButton_clicked()
{
    addCartDialog *t = new addCartDialog(this);
    t->show();
    connect(t,SIGNAL(sendName(QString)),this,SLOT(searchName(QString)));
}

void Cart::newPro(Product a)
{
    pro.push_back(a);
}

void Cart::searchName(QString a)
{

    QVector<Product>::iterator i = pro.begin();
    for(; i != pro.end(); i++){
        if(a == i->getname()){
            i->setinCart(true);

            //qDebug() << "hi";
            break;
        }
       // qDebug() << "shit";
    }

    ui->table->insertRow(0);
    //ui->table->setRowCount(1);
    QLineEdit *nameedit = new QLineEdit();
    nameedit->setText(i->getname());
    //l->addWidget(nameedit);
    ui->table->setCellWidget(0,0,nameedit);

    QLineEdit *priceedit = new QLineEdit();
    priceedit->setText(QString::number(i->getprice()));
    //l->addWidget(priceedit);
    ui->table->setCellWidget(0,1,priceedit);

    QSpinBox *numbspin = new QSpinBox();
    numbspin->setMaximum(i->getnumber());
    //l->addWidget(numbspin);
    ui->table->setCellWidget(0,2,numbspin);
    i->setSpin(numbspin);
    //total.append(*i);

}

void Cart::on_finishbtn_clicked()
{
    int sumProduct = 0;
    QVector<Product>::iterator f = pro.begin();
    //int sz = pro.size();
    for(; f < pro.end(); f++){
        if(f->getinCart()){
            int spinval = f->getspin()->value();
            //qDebug() << f->getwant();
            sumProduct += (f->getprice()) * spinval;
            int tmp = (f->getnumber()) - spinval;
            f->setnumber(tmp);
            //qDebug() << "hi";
        }
       // qDebug() << "hi2";
    }
    //qDebug() << "hi3";

    QMessageBox::information(this,"Total Price:",QString::number(sumProduct));
    //qDebug() << sumProduct;
    ui->table->setRowCount(0);
}
