#ifndef PRODUCT_H
#define PRODUCT_H
#include <iostream>
#include <QWidget>
#include <QString>
#include <QSpinBox>
using namespace std;

class Product{
    QString name;
    QString catagory;
    int price;
    int number;
    //int want;
    bool inCart;
    QSpinBox *spin;
public:
    Product();
    Product(QString _name, QString _catagory , int _price , int _number);
    QString getname(){ return name;}
    int getprice(){ return price;}
    int getnumber(){ return number;}
    void setnumber(int _number){ number = _number; }
    QString getcatagory(){ return catagory; }
    void setcatagory(QString _catagory){ catagory = _catagory; }
//    int getwant(){ return want; }
//    void setwant(int _wantfromthisgoods){ want = _wantfromthisgoods; }
    bool getinCart(){ return inCart; }
    void setinCart(bool _inCart){ inCart = _inCart; }
    QSpinBox* getspin(){ return spin; }
    void setSpin(QSpinBox* _spin){ spin = _spin; }
};

#endif // PRODUCT_H
