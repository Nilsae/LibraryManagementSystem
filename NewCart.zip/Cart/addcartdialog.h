#ifndef ADDCARTDIALOG_H
#define ADDCARTDIALOG_H

#include <QDialog>

namespace Ui {
class addCartDialog;
}

class addCartDialog : public QDialog
{
    Q_OBJECT

public:
    explicit addCartDialog(QWidget *parent = nullptr);
    ~addCartDialog();
signals:
    void sendName(QString a);
private slots:
    void on_buttonBox_accepted();

private:
    Ui::addCartDialog *ui;
};

#endif // ADDCARTDIALOG_H
