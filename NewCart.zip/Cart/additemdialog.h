#ifndef ADDITEMDIALOG_H
#define ADDITEMDIALOG_H

#include <QDialog>
#include "product.h"
namespace Ui {
class additemDialog;
}

class additemDialog : public QDialog
{
    Q_OBJECT

public:
    explicit additemDialog(QWidget *parent = nullptr);
    ~additemDialog();
signals:
    void sendProduct(Product a);
private slots:
    void on_buttonBox_accepted();

private:
    Ui::additemDialog *ui;
};

#endif // ADDITEMDIALOG_H
