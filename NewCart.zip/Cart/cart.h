#ifndef CART_H
#define CART_H

#include <QWidget>
#include "product.h"
#include <QVector>
#include <QMessageBox>
#include <QSpinBox>
#include <QLineEdit>
#include <QDebug>
#include <QHBoxLayout>
#include <QMap>

QT_BEGIN_NAMESPACE
namespace Ui { class Cart; }
QT_END_NAMESPACE

class Cart : public QWidget
{
    Q_OBJECT

public:
    Cart(QWidget *parent = nullptr);
    ~Cart();

private slots:
    void on_additembtn_clicked();

    void on_pushButton_clicked();

    void newPro(Product a);

    void searchName(QString a);

    void on_finishbtn_clicked();

private:
    Ui::Cart *ui;
    QVector<Product> pro;
    QVector<Product> total;
    static int counter;
};
#endif // CART_H
