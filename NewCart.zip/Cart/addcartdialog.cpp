#include "addcartdialog.h"
#include "ui_addcartdialog.h"

addCartDialog::addCartDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addCartDialog)
{
    ui->setupUi(this);
}

addCartDialog::~addCartDialog()
{
    delete ui;
}

void addCartDialog::on_buttonBox_accepted()
{
    emit sendName(ui->lineEdit->text());
}
