#include "additemdialog.h"
#include "ui_additemdialog.h"

additemDialog::additemDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::additemDialog)
{
    ui->setupUi(this);
    ui->namelineEdit->setFocus();
}

additemDialog::~additemDialog()
{
    delete ui;
}

void additemDialog::on_buttonBox_accepted()
{
    QString name = ui->namelineEdit->text();
    QString cat = ui->catagorylineEdit->text();
    int price = ui->pricespinBox->value();
    int numb = ui->spinBox->value();
    Product p(name,cat,price,numb);
    emit sendProduct(p);
}
