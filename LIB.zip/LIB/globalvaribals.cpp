#include "globalvaribals.h"
int GlobalVaribals::CurrentId=-1;
int GlobalVaribals::CurrentAccType=-1;
GlobalVaribals::GlobalVaribals()
{

}
