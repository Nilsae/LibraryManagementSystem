#ifndef GLOBALVARIBALS_H
#define GLOBALVARIBALS_H
#include <QtGlobal>

class GlobalVaribals
{
public:
    static int CurrentId;
    static int CurrentAccType;
    //static QString CurrentId1;
    GlobalVaribals();
};

#endif // GLOBALVARIBALS_H
