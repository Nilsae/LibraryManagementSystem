# LibraryManagementSystem
Library Management System in C++ and Qt - AP Project @IUT
Project by Niloufar Saeedi, Mahsa Amini, Alireza Mousavi
Course presented by Ehsan Mahdavi
