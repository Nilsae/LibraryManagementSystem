#include "globalvaribals.h"
int GlobalVaribals::CurrentId=-1;
//QString GlobalVaribals::CurrentId1(CurrentId1);
GlobalVaribals::GlobalVaribals()
{

}
